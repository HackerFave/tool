#include "baseObject.h"

baseObject::baseObject(QObject *parent) : QObject(parent)
{

}
