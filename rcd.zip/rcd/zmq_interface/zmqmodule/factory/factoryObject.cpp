﻿#include "factoryObject.h"

factoryObject::factoryObject()
{

}
