## Control

用于采集控制器数据，通过zmq对外发布控制数据



### 安装依赖关系

1. 安装libusb-1.0 和libudev

   ```shell
   sudo apt install libusb-1.0-0-dev libudev-dev
   ```



2. 安装 [hidapi-0.9.0](https://github.com/libusb/hidapi/releases/tag/hidapi-0.9.0), [安装参考](https://github.com/libusb/hidapi#build-instructions)

   
   
   