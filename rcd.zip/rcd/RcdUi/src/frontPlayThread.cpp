﻿#include "frontPlayThread.h"

frontPlayThread::frontPlayThread(QObject *parent) : QObject(parent)
{

}
