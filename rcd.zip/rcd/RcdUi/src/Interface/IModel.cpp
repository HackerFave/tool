#include "IModel.h"

IModel::IModel(QObject *parent) :
    QObject(parent)
{

}

IModel::~IModel()
{

}
