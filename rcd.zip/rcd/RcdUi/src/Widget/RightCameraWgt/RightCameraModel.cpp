#include "RightCameraModel.h"

RightCameraModel::RightCameraModel(QObject *parent) : IModel(parent)
{
    m_select = 1;
}

