#include "LeftCameraModel.h"

LeftCameraModel::LeftCameraModel(QObject *parent) : IModel(parent)
{

}

