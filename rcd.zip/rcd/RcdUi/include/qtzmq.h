#ifndef QTZMQ
#define QTZMQ

#include <QObject>
#include <QMetaType>

#include "zmq/zmqmsg.hpp"
#include "zmq/zmqwrap.hpp"

Q_DECLARE_METATYPE(VehicleStatus);

#endif // QTZMQ
